/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "I2c_LCD.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
//char RxBuffer[RXBUFFERSIZE];
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
float Temperature = 0;
int set_temperature = 25;
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	uint8_t len;
	uint16_t times = 0;
	uint16_t adcx;
	float temp;
	uint16_t pwmval = 0;
	float error = 0;
	float e_error = 0;
	float del_error = 0;
	float Kp = 1;
	float Kd = 0.5;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_I2C3_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  lcd_init();
  lcd_send_string("ENGN8170 SAMPLE STAGE");
  lcd_put_cur(1,0);
  char temperature_strff[20];
  char set_temperature_strff[20];
  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, pwmval);
  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pwmval);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  adcx = adc_get_result_average(20);
	  temp = (float)adcx * (3.3 / 4096);
	  Temperature = (float)-325 + ((625 * temp)/3);
	  e_error = error;
	  error = set_temperature - Temperature;
	  del_error = error - e_error;
	  uint16_t e_pwmval = pwmval;
	  pwmval = (int)pwmval + Kp * error + Kd*del_error;
	  if(pwmval < 1000 && pwmval > 0)
	  {
		  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, pwmval);
		  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pwmval);
	  	}
	  else{
	  	  pwmval = e_pwmval;
	  	  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, pwmval);
	  	  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pwmval);
	  		}
      if (g_usart_rx_sta & 0x8000)
       {
           len = g_usart_rx_sta & 0x3fff;
           if(g_usart_rx_buf[0] == 0x30 && g_usart_rx_buf[1] == 0x31)
           {
        	   int hundred = (int)g_usart_rx_buf[3] - 48;//010345
        	   int ten = (int)g_usart_rx_buf[4] - 48;
        	   int ge = (int)g_usart_rx_buf[5] - 48;
        	   if((int)g_usart_rx_buf[2] == 48)
        		   set_temperature = 100*hundred + 10*ten + ge;
        	   else
        		   set_temperature = -(100*hundred + 10*ten + ge);

               sprintf(set_temperature_strff,"%d",set_temperature);
               HAL_UART_Transmit(&huart2, (uint8_t*)set_temperature_strff, strlen(set_temperature_strff), 1000);
               while(__HAL_UART_GET_FLAG(&huart2,UART_FLAG_TC)!=SET);
               g_usart_rx_sta = 0;
           }
           if(g_usart_rx_buf[0] == 0x31 && g_usart_rx_buf[1] == 0x31)
           {
        	   int temper = (int)Temperature;
        	   sprintf(temperature_strff,"%d",temper);
        	   //char adc_strff[100];
        	   //sprintf(adc_strff,"%d",adcx);
        	   HAL_UART_Transmit(&huart2, (uint8_t*)temperature_strff, strlen(temperature_strff), 1000);
        	   while(__HAL_UART_GET_FLAG(&huart2,UART_FLAG_TC)!=SET);
        	   g_usart_rx_sta = 0;
           }
       }
       else
       {
           times++;

           if (times % 5000 == 0)
           {
           }
           if (times % 200 == 0)

           if (times % 30  == 0)

           HAL_Delay(100);
       }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 72;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

//void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
//{
//  /* Prevent unused argument(s) compilation warning */
//  UNUSED(huart);
//  /* NOTE: This function Should not be modified, when the callback is needed,
//           the HAL_UART_TxCpltCallback could be implemented in the user file
//   */
//
//	if(Uart2_Rx_Cnt >= 255)  //溢出判断
//	{
//		Uart2_Rx_Cnt = 0;
//		memset(RxBuffer,0x00,sizeof(RxBuffer)); //清空数组
//		lcd_send_string("RECEIVE");
//		HAL_Delay(1000);
//		lcd_put_cur(1, 0);
//		lcd_clear();
//		HAL_GPIO_WritePin(led_g_GPIO_Port, led_g_Pin, GPIO_PIN_SET);
//		HAL_Delay(200);
//		HAL_GPIO_WritePin(led_g_GPIO_Port, led_g_Pin, GPIO_PIN_RESET);
//		HAL_Delay(200);
//	}
//	else
//	{
//		RxBuffer[Uart2_Rx_Cnt++] = aRxBuffer;
//
//		if((RxBuffer[Uart2_Rx_Cnt-1] == 0x0A)&&(RxBuffer[Uart2_Rx_Cnt-2] == 0x0D))
//		{
//			//HAL_UART_Transmit(&huart1, (uint8_t *)&RxBuffer, Uart1_Rx_Cnt,0xFFFF); //将收到的信息发�?�出�??????
//            while(HAL_UART_GetState(&huart2) == HAL_UART_STATE_BUSY_TX);//�??????测UART发�?�结�??????
//			Uart2_Rx_Cnt = 0;
//			memset(RxBuffer,0x00,sizeof(RxBuffer)); //清空数组
//			lcd_send_string("RECEIVE");
//			HAL_Delay(1000);
//			Uart2_Rx_Cnt = 0;
//			lcd_put_cur(1, 0);
//			lcd_clear();
//			HAL_GPIO_WritePin(led_g_GPIO_Port, led_g_Pin, GPIO_PIN_SET);
//			HAL_Delay(200);
//			HAL_GPIO_WritePin(led_g_GPIO_Port, led_g_Pin, GPIO_PIN_RESET);
//			HAL_Delay(200);
//		}
//	}
//
//	HAL_UART_Receive_IT(&huart2, (uint8_t *)&aRxBuffer, 1);   //再开启接收中�??????
//}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
